# Road-Conditioned Diffusion for Traffic Trajectory Synthesis

English thesis research draft **v19**. Main document: `main.tex`; compiler: pdfLaTeX. The checked build contains **109 PDF pages**, **75 pages of main text**, **31 figures**, **22 tables** and **52 cited bibliography entries**.

## Five classes in the main results

Bus, motorcycle, private car, bicycle and taxi/ride-hailing each receive a complete generated-journey panel and an exact spatial/velocity GAF panel in the main text, using the unchanged fixed first-request rule. The main results add a complete five-class, six-motion-endpoint figure and absolute native-speed/acceleration error table. Current-reader per-class F1 is shown separately from synthetic-trajectory quality. The discussion covers the representation-dependent gains and adverse outcomes for every class; it does not tune a different selector for each class after observing the results.

Earlier/current corpus, generator and teacher comparisons move to the appendix as supporting diagnostics. They are not a scaling-law study. The matched native-clock versus 257-point pilot remains a central representation control. No new simulation, fitting, sampling, scoring or test access was performed for this manuscript revision.

Visual provenance remains in `../docs/results/thesis-v18-visuals.json`; new complete-class tables and figure derive from `../docs/results/thesis-v19-assets.json` and `tools/build_five_class_assets.py`. The Overleaf package includes all referenced assets and needs no server connection. Future data priorities, explicitly not launched, are in `../docs/FIVE_CLASS_NEXT_STEPS.md`.

## Document structure

The main text has eight chapters: introduction, related work, data, complete-journey diffusion, GAF feedback, experimental protocol, results, and discussion/conclusions. The appendix retains the full G33 physical metric matrix, class-wise native-resolution distances, five pilot cases selected by a fixed request-order rule, old/new corpus diagnostics, and the scope of earlier evidence. The source files included by `main.tex` define the current manuscript; retained historical chapter files are not all part of this build.

The bibliography contains **52 entries**: 47 research papers or preprints, one master's thesis, two code repositories and two official documentation entries. This count does not mean 52 peer-reviewed papers. The related-work chapter organizes their relevance to trajectory generation, temporal representation, feedback and evaluation.

## Open in Overleaf or build locally

Upload the thesis source package as a new Overleaf project, choose `main.tex` as the main document and pdfLaTeX as compiler, and use a recent TeX Live release with `toptesi`. No shell escape or runtime data connection is required to compile the supplied manuscript and figures. From this directory, use `latexmk -pdf main.tex`, or run `pdflatex main.tex` three times to resolve references.

Before submission, replace the administrative placeholders in `metadata.tex`: candidate name, degree programme, supervisor, academic year and graduation session. Check the working title and subtitle as well. These fields are intentionally unconfirmed; this is a research draft rather than a submission-ready administrative record. `cover.tex` adapts the referenced PoliTo layout; see [TEMPLATE.md](TEMPLATE.md) for attribution. The earlier same-school thesis length is a comparison, not a university page-count requirement.

## Expanded results added in v17

- G35:29,895 training legs/24,073 parents,7,230 development legs/5,842 parents. Four completed diffusion fits and two fixed readers. The matched development audit raises spatial macroF1 from50.10% to76.47% and velocity macroF1 from61.82% to90.34%. Training volume, temporal coverage and CNN update count change jointly.
- G36:two new SUMO episodes,100requests each, eight generated pools and48selected evaluations. Quality intersections95/94; old/new teachers score identical expanded-generator pools. Expanded native generation has scene-dependent gains, not universal improvement.
- Post-hoc full-metric audit:spatial longest-stop requestMAE improves7.6% overall and20.7% for buses, while motorcycle error increases5.3%. W1 and all adverse endpoints remain in the main result matrix. This is an exploratory class-specific mechanism, not confirmation of station-correct stopping, dual-view synergy or in-loop guidance.
- Eight new vector figures and five automatically generated numerical tables derive from frozen aggregate JSON receipts; two additional protocol/coverage tables are in the text. `tools/build_expansion_assets.py` reproduces new assets. Input hashes are recorded in `../docs/results/thesis-v17-assets.json`. The manuscript package includes final figures; building it requires no Python or live server.

## Current evidence and its scope

- **G33:** 925 native SUMO vehicle legs for training and 126 for development; two temporal representations, two model seeds and four completed diffusion fits. Six full candidate pools each contain 776 trajectories. The two native-clock models also support Uniform, spatial, velocity and joint selection, giving eight selected-set evaluations. The original denominator is 100 requests, map support and reference acceptance are each 97, and independent physical quality is paired on their 94-request intersection. The native-clock generator improves acceleration distributions while retaining stopping and computation tradeoffs. See the [completed report](../docs/results/g33-generation/REPORT.md) and [complete numerical summary](../docs/results/g33-generation/report/summary.json).
- **G34:** a completed post-G33 mechanism control fixes each request's duration to its predetermined old-Uniform training-prior draw. Two native model seeds generate K=8 candidates without retraining diffusion, the prior or either CNN. The old and new Uniform trajectories are verified bitwise identical for all 97 requests per seed. The same 94 paired references are reused, so this is development evidence, not a new blind evaluation. Velocity-GAF selection improves native acceleration and longest-stop distances in both seeds, with worse steady-movement and p95-speed distances; no universal feedback benefit is claimed. See the [fixed protocol](../docs/G34_PROTOCOL.md) and [completed attempt2 summary](../docs/results/g34-fixed-duration/attempt2/report/summary.json).
- Both GAF readers are trained within this project. Spatial images inherit the original Hilbert/GASF/GADF/MTF construction; velocity images are a separate transform of speeds derived from timestamps and positions. There are no supplied group CNN weights. The current comparisons use **terminal selection**, not in-loop guidance, and do not establish a new downstream augmentation benefit.
- The training pilot and evaluation reference use the same public MoST map and demand families. New simulation randomness does not demonstrate unseen-city or unseen-line generalization. Simulator observations are not physical-road measurements; the system does not model interacting agents jointly.

Earlier findings remain available with their original populations. The [locked E7 report](../docs/results/final-test-e7/REPORT.md) concerns 53 eligible moving-window requests out of 270 held-out IDs. The [G28 paired-latent study](../docs/results/g28-paired-latents/REPORT.md) records the earlier eight-class supervision comparison, including its inconclusive physical gains. Neither population is pooled with G33/G34, and the old test is not used to select the current method.

## Tables, figures and reproduction

G33 numerical tables derive from the completed JSON summaries; figure provenance and the unchanged case-selection rule are recorded in [the paper-figure receipt](../docs/results/g33-generation/paper-figures/complete.json). The five cases use model seed 42 and the first lexicographic request in each class jointly supported by the reference and all four policies. They are not selected for visual quality. Case speed curves summarize complete one-second intervals and omit the final partial second; native-resolution distribution measures are reported separately.

G34's [summary](../docs/results/g34-fixed-duration/attempt2/report/summary.json) records the shared-duration and exact-Uniform checks, per-class support, source hashes and all ten completed evaluations. Protocols, failures and completed attempts remain in the experiment records; the successful attempt does not overwrite the preceding record.

The experiment scripts and versioned manifests are in the repository. Re-running experiments requires the corresponding source observations, public SUMO scenario and model artifacts, which are separate from the manuscript package. Raw participant data, model weights and access credentials are not embedded in the thesis ZIP or committed as thesis assets. The manuscript build uses prepared tables and figures and does not require a live training server.
